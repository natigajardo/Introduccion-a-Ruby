n = ARGV[0].to_i
puts " numero ingresado #{n}"

 i = 0
n.times do |f|
  puts i+1
  i += 2
end
