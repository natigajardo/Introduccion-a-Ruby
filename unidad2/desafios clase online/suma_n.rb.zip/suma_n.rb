numero = ARGV[0].to_i
i = 0
suma = 0

while i < numero
  i += 1
  suma += i
  puts i #Para comprobar que parte del 1
end

puts suma #Suma total entre el 0 y todos los numeros entre él y el numero elegido
