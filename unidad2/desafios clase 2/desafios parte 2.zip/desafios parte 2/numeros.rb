n = ARGV[0].to_i
i = 0

  for i in (1..n)
    for j in (1..i)
    print j
    end
    print " "
  end
